﻿namespace TeisterMask.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=TOLKATA;Database=TeisterMaskExam;Trusted_Connection=True";
    }
}
