﻿namespace TeisterMask.DataProcessor.ExportDto
{
    using System.Xml.Serialization;

   
    public class ExportProjectDto
    {
       
    }
}
