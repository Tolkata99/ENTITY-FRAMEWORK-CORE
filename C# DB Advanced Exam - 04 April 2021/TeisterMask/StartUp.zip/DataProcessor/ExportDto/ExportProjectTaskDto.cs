﻿namespace TeisterMask.DataProcessor.ExportDto
{
    using System.Xml.Serialization;


    public class ExportProjectTaskDto
    {
      
    }
}
