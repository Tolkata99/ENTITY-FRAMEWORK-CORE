﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Text;

namespace CarDealer.Data
{
    public static class Configuration
    {
        public const string ConnectionString = "Server =TOLKATA; Database=CarDealer;Trusted_Connection=True;";
    }
}
