﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProductShop.Dtos.InputModel
{
    public class CategoriesInputDto
    {
        public string Name { get; set; }
    }
}
